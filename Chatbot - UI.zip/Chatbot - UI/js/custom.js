$(function(){
	$('.chat-bot-messages').slimScroll({
        height: '200px',
        alwaysVisible: true,
        railVisible: true,
        railColor: '#ccc'
	});
});