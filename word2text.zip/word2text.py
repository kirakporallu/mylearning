training_doc3 = """
create credit card for card type as VISA . 
how to post credit card transactions . 
reserve 100 accounts from CCA accounts . 
Produce credit card with card type as AMEX . 
what is reversal transactions . 
how to know the status of my CRQ . 
help me with CRQ Status . 
where to find the CRQ status . 
what is IMPACS tranasctions .  
Show me my last reservartion list .  
want to know status of my online id . 
when is the next training date scheduled for DataX .  
create weaseless account .  
im unable to find accounts for my query what to do . 
help me with automation task .  
with Card type as MASTER please create a credit card .  
post credit card transactions . 
"""

from keras.preprocessing.text import Tokenizer
import spacy
from spacy.tokens import Doc
#from nltk.tokenize import word_tokenize
import numpy as np
import re
from keras.utils import to_categorical
cleaned = re.sub(r'\W+', ' ', training_doc3)
nlp = spacy.load("en_core_web_sm")
Doc = nlp(cleaned)
train_len = 3+1
#tokens = Doc
text_sequences = []
tokens = [token.text for token in Doc]
for i in range(train_len,len(tokens)):
     seq = tokens[i-train_len:i]
     text_sequences.append(seq)
print(text_sequences)  
sequences = {}
count = 1
for i in range(len(tokens)):
    if tokens[i] not in sequences:
        sequences[tokens[i]] = count
        count += 1
print(text_sequences)
tokenizer = Tokenizer()
tokenizer.fit_on_texts(text_sequences)
print(text_sequences)
sequences = tokenizer.texts_to_sequences(text_sequences) 

#Collecting some information   
vocabulary_size = len(tokenizer.word_counts)+1

n_sequences = np.empty([len(sequences),train_len], dtype='int32')
for i in range(len(sequences)):
    n_sequences[i] = sequences[i]
    #print(n_sequences[i])

train_inputs = n_sequences[:,:-1]
train_targets = n_sequences[:,-1]
train_targets = to_categorical(train_targets, num_classes=vocabulary_size)
seq_len = train_inputs.shape[1]
train_inputs.shape

from keras.models import Sequential, load_model
from keras.layers import Dense
from keras.layers import LSTM
from keras.layers import Embedding
#model = load_model("mymodel.h5")

model = Sequential()
model.add(Embedding(vocabulary_size, seq_len, input_length=seq_len))
model.add(LSTM(50,return_sequences=True))
model.add(LSTM(50))
model.add(Dense(50,activation='relu'))
model.add(Dense(vocabulary_size, activation='softmax'))
print(model.summary())
# compile network
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.fit(train_inputs,train_targets,epochs=100,verbose=1)
model.save("mymodel.h5")
import pickle
 
with open('tokenizer.pickle', 'wb') as handle:
    pickle.dump(tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)

